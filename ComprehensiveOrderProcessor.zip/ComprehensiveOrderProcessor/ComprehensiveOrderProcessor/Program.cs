﻿using ComprehensiveOrderProcessor.Orders;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;

namespace ComprehensiveOrderProcessor
{
    class Program
    {
        static void Main(string[] args)
        {
            // setting to read "appsettings.json
            var builder = new ConfigurationBuilder()
            .SetBasePath(Directory.GetCurrentDirectory())
            .AddJsonFile("appsettings.json");

            var configuration = builder.Build();


            // Feed the list of orders to be processed by Comprehensive order processor
            List<Order> orders = new List<Order>()
            {
               new PhysicalProductOrder(),
               new BookOrder(),
               new MembershipOrder(),
               new UpgradeMembershipOrder(),
               new VideoOrder("Learning to Ski")
            };

           

            foreach (Order order in orders)
            {
                //Reading Rules associated to order category from config file
                var orderRules = configuration.GetSection(order.GetType().Name.ToString()).Value;

                order.HandleOrder(orderRules);
            }

            Console.ReadKey();
        }
    }
}
