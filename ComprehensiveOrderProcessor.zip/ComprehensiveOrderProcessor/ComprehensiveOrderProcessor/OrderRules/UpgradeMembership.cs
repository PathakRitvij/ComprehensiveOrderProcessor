﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ComprehensiveOrderProcessor.OrderRules
{
    public class UpgradeMembership : IOrderRule
    {
        public void ApplyRule()
        {
            Console.WriteLine("\t Upgraded Membership");
        }
    }
}
