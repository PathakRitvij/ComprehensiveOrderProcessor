﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ComprehensiveOrderProcessor.OrderRules
{
    public class GenerateComission : IOrderRule
    {
        public void ApplyRule()
        {
            Console.WriteLine(" \t Generated a commission payment to the agent");
        }
    }
}
