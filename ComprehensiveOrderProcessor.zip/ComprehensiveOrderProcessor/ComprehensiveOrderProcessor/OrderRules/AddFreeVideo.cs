﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ComprehensiveOrderProcessor.OrderRules
{
    public class AddFreeVideo : IOrderRule
    {
        public void ApplyRule()
        {
            Console.WriteLine("\t added a free First Aid video to the packing slip");
        }
    }
}
