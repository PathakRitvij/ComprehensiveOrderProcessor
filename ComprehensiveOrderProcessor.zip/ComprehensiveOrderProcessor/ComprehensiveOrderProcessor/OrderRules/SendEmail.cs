﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ComprehensiveOrderProcessor.OrderRules
{
    public class SendEmail : IOrderRule
    {
        public void ApplyRule()
        {
            Console.WriteLine("\t e-mail the owner and inform them of the activation/upgrade");
        }
    }
}
