﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ComprehensiveOrderProcessor.OrderRules
{
    public class ActivateMembership : IOrderRule
    {
        public void ApplyRule()
        {
            Console.WriteLine("\t Activated Membership");
        }
    }
}
