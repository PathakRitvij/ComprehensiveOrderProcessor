﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ComprehensiveOrderProcessor.OrderRules
{
   public interface IOrderRule
    {
        void ApplyRule();

    }
}
