﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ComprehensiveOrderProcessor.OrderRules
{
    public class CreateDuplicatePackingSlip : IOrderRule
    {
        public void ApplyRule()
        {
            Console.WriteLine("\t Created a duplicate packing slip for the royalty department");
        }
    }
}
