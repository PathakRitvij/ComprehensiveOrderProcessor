﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ComprehensiveOrderProcessor.OrderRules
{
    public class GeneratePackingSlip : IOrderRule
    {
        public void ApplyRule()
        {
            Console.WriteLine("\t Generated a packing slip for shipping");
        }
    }
}
