﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ComprehensiveOrderProcessor.Orders
{
    public class PhysicalProductOrder : Order
    {
        public override string Category { get { return "Physical Product"; } }

    }
}
