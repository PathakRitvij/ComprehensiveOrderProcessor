﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ComprehensiveOrderProcessor.Orders
{
    public class UpgradeMembershipOrder : Order
    {
        public override string Category { get { return "Upgrade Membership"; } }
    }
}
