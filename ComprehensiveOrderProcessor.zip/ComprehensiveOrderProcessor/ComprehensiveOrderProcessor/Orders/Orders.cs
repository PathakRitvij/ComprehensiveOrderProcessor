﻿using System;
using System.Collections.Generic;
using System.Text;
using ComprehensiveOrderProcessor.OrderRules;

namespace ComprehensiveOrderProcessor.Orders
{
    public abstract class Order
    {
        // properties of an Order 
        public abstract string Category { get; }

        public const string RULE_NAMESPACE = "ComprehensiveOrderProcessor.OrderRules";
        public string Name { get; set; }


        // Hndle order method can be overriden to provide order category specific logic in concrete classes.
        public virtual void HandleOrder(string rules)
        {
            Console.WriteLine($"Processing order for {Category}");

            string[] orderRules = rules.Split(",");
            foreach (string rule in orderRules)
            {
                Type t = Type.GetType($"{RULE_NAMESPACE}.{rule}");
                IOrderRule geratedOrderRule = Activator.CreateInstance(t) as IOrderRule;
                geratedOrderRule.ApplyRule();
            }
            Console.WriteLine("\n");
        }

    }

}
