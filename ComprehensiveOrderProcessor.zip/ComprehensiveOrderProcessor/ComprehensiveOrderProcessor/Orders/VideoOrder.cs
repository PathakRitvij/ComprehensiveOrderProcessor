﻿using System;
using System.Collections.Generic;
using System.Text;
using ComprehensiveOrderProcessor.OrderRules;

namespace ComprehensiveOrderProcessor.Orders
{
    public class VideoOrder : Order
    {
        public VideoOrder(string name)
        {
            this.Name = name;
        }
        public override string Category { get { return "Video"; } }

        public override void HandleOrder(string rules)
        {
            Console.WriteLine($"Processing order for {Category}");
            string[] orderRules = rules.Split(",");
            foreach (string rule in orderRules)
            {
                Type t = Type.GetType($"{RULE_NAMESPACE}.{rule}");
                if (t != null)
                {
                    IOrderRule geratedOrderRule = Activator.CreateInstance(t) as IOrderRule;
                    if (rule.Equals("AddFreeVideo", StringComparison.OrdinalIgnoreCase))
                    {
                        if (this.Name.Equals("Learning to Ski", StringComparison.OrdinalIgnoreCase))
                        {
                            geratedOrderRule.ApplyRule();
                        }
                    }
                    else
                    {
                        geratedOrderRule.ApplyRule();
                    }

                }
            }
            Console.WriteLine("\n");
        }
    }
}
